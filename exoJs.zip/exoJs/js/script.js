function updateTotal() {
  let total = 0;

  const productCards = document.querySelectorAll('.list-products .card');
  productCards.forEach(card => {
    const priceText = card.querySelector('.unit-price')?.textContent || '0';
    const quantityText = card.querySelector('.quantity')?.textContent || '0';

    const price = parseFloat(priceText.replace('$', '').trim());
    const quantity = parseInt(quantityText.trim());

    total += price * quantity;
  });


  const totalDisplay = document.querySelector('.total');
  if (totalDisplay) {
    totalDisplay.textContent = `${total} $`;
  }
}

document.querySelectorAll('.fa-plus-circle').forEach(btn => {
  btn.addEventListener('click', () => {
    const quantityEl = btn.parentElement.querySelector('.quantity');
    if (quantityEl) {
      quantityEl.textContent = parseInt(quantityEl.textContent) + 1;
      updateTotal();
    }
  });
});


document.querySelectorAll('.fa-minus-circle').forEach(btn => {
  btn.addEventListener('click', () => {
    const quantityEl = btn.parentElement.querySelector('.quantity');
    if (quantityEl) {
      const currentQty = parseInt(quantityEl.textContent);
      if (currentQty > 0) {
        quantityEl.textContent = currentQty - 1;
        updateTotal();
      }
    }
  });
});


document.querySelectorAll('.fa-trash-alt').forEach(btn => {
  btn.addEventListener('click', () => {
    const card = btn.closest('.card');
    if (card) {
      card.remove();
      updateTotal();
    }
  });
});

document.querySelectorAll('.fa-heart').forEach(btn => {
  btn.addEventListener('click', () => {
    btn.classList.toggle('liked');
    btn.style.color = btn.classList.contains('liked') ? 'red' : 'black';
  });
});

updateTotal();

